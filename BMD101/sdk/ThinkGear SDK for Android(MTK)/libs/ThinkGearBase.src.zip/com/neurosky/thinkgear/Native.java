/*   */ package com.neurosky.thinkgear;
/*   */ 
/*   */ public class Native
/*   */ {
/*   */   static
/*   */   {
/* 7 */     System.loadLibrary("JRDBCM");
/*   */   }
/*   */ }

/* Location:           C:\Users\Chris\Desktop\ThinkGear SDK for Android(MTK)\libs\ThinkGearBase.jar
 * Qualified Name:     com.neurosky.thinkgear.Native
 * JD-Core Version:    0.6.0
 */