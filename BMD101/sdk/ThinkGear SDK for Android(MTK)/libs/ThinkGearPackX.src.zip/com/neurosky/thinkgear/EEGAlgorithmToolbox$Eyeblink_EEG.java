package com.neurosky.thinkgear;

public class EEGAlgorithmToolbox$Eyeblink_EEG
{
  public EEGAlgorithmToolbox$Eyeblink_EEG(EEGAlgorithmToolbox paramEEGAlgorithmToolbox)
  {
  }

  public double[] eyeblink_fun(double[] paramArrayOfDouble)
  {
    int i = paramArrayOfDouble.length;
  }
}

/* Location:           C:\Users\Chris\Desktop\ThinkGear SDK for Android(MTK)\libs\ThinkGearPackX.jar
 * Qualified Name:     com.neurosky.thinkgear.EEGAlgorithmToolbox.Eyeblink_EEG
 * JD-Core Version:    0.6.0
 */