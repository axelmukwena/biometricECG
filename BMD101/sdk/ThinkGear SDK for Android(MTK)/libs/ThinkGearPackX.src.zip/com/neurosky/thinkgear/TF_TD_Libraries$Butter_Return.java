package com.neurosky.thinkgear;

public class TF_TD_Libraries$Butter_Return
{
  protected double[] _B;
  protected double[] _A;

  public TF_TD_Libraries$Butter_Return(TF_TD_Libraries paramTF_TD_Libraries, double[] paramArrayOfDouble1, double[] paramArrayOfDouble2)
  {
    this._B = paramArrayOfDouble1;
    this._A = paramArrayOfDouble2;
  }

  public double[] get_B()
  {
    return this._B;
  }

  public double[] get_A()
  {
    return this._A;
  }
}

/* Location:           C:\Users\Chris\Desktop\ThinkGear SDK for Android(MTK)\libs\ThinkGearPackX.jar
 * Qualified Name:     com.neurosky.thinkgear.TF_TD_Libraries.Butter_Return
 * JD-Core Version:    0.6.0
 */