package com.neurosky.thinkgear;

public class EEGAlgorithmToolbox$Hjorth_Return
{
  protected double _activity_UC0;
  protected double _mobility_UC0;
  protected double _complexity_UC0;

  public EEGAlgorithmToolbox$Hjorth_Return(EEGAlgorithmToolbox paramEEGAlgorithmToolbox, double paramDouble1, double paramDouble2, double paramDouble3)
  {
    this._activity_UC0 = paramDouble1;
    this._mobility_UC0 = paramDouble2;
    this._complexity_UC0 = paramDouble3;
  }

  public double get_activity()
  {
    return this._activity_UC0;
  }

  public double get_mobility()
  {
    return this._mobility_UC0;
  }

  public double get_complexity()
  {
    return this._complexity_UC0;
  }
}

/* Location:           C:\Users\Chris\Desktop\ThinkGear SDK for Android(MTK)\libs\ThinkGearPackX.jar
 * Qualified Name:     com.neurosky.thinkgear.EEGAlgorithmToolbox.Hjorth_Return
 * JD-Core Version:    0.6.0
 */