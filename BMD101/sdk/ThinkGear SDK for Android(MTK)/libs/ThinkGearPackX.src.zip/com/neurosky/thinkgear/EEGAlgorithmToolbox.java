package com.neurosky.thinkgear;

public class EEGAlgorithmToolbox
{
}

/* Location:           C:\Users\Chris\Desktop\ThinkGear SDK for Android(MTK)\libs\ThinkGearPackX.jar
 * Qualified Name:     com.neurosky.thinkgear.EEGAlgorithmToolbox
 * JD-Core Version:    0.6.0
 */