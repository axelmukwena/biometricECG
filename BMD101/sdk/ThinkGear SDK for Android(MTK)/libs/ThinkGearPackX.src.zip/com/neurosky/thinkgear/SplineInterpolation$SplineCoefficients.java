package com.neurosky.thinkgear;

import java.util.ArrayList;
import java.util.List;

public class SplineInterpolation$SplineCoefficients
{
  public List A = new ArrayList();
  public List B = new ArrayList();
  public List C = new ArrayList();
  public List D = new ArrayList();

  public SplineInterpolation$SplineCoefficients(SplineInterpolation paramSplineInterpolation)
  {
  }

  public void clearAll()
  {
    this.A.clear();
    this.B.clear();
    this.C.clear();
    this.D.clear();
  }
}

/* Location:           C:\Users\Chris\Desktop\ThinkGear SDK for Android(MTK)\libs\ThinkGearPackX.jar
 * Qualified Name:     com.neurosky.thinkgear.SplineInterpolation.SplineCoefficients
 * JD-Core Version:    0.6.0
 */