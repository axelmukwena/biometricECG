package com.neurosky.thinkgear;

public class TGRawMulti
{
  public int ch1;
  public int ch2;
  public int ch3;
  public int ch4;
  public int ch5;
  public int ch6;
  public int ch7;
  public int ch8;
  public int timeStamp1;

  public TGRawMulti(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5, int paramInt6, int paramInt7, int paramInt8)
  {
    this.ch1 = paramInt1;
    this.ch2 = paramInt2;
    this.ch3 = paramInt3;
    this.ch4 = paramInt4;
    this.ch5 = paramInt5;
    this.ch6 = paramInt6;
    this.ch7 = paramInt7;
    this.ch8 = paramInt8;
  }

  public TGRawMulti()
  {
    this(0, 0, 0, 0, 0, 0, 0, 0);
  }
}

/* Location:           C:\Users\Chris\Desktop\ThinkGear SDK for Android(MTK)\libs\ThinkGearPackX.jar
 * Qualified Name:     com.neurosky.thinkgear.TGRawMulti
 * JD-Core Version:    0.6.0
 */