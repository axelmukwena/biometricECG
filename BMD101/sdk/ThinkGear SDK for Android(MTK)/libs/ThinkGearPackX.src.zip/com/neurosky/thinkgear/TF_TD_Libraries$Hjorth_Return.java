package com.neurosky.thinkgear;

public class TF_TD_Libraries$Hjorth_Return
{
  protected double _activity_UC0;
  protected double _mobility_UC0;
  protected double _complexity_UC0;

  public TF_TD_Libraries$Hjorth_Return(TF_TD_Libraries paramTF_TD_Libraries, double paramDouble1, double paramDouble2, double paramDouble3)
  {
    this._activity_UC0 = paramDouble1;
    this._mobility_UC0 = paramDouble2;
    this._complexity_UC0 = paramDouble3;
  }

  public double get_activity()
  {
    return this._activity_UC0;
  }

  public double get_mobility()
  {
    return this._mobility_UC0;
  }

  public double get_complexity()
  {
    return this._complexity_UC0;
  }
}

/* Location:           C:\Users\Chris\Desktop\ThinkGear SDK for Android(MTK)\libs\ThinkGearPackX.jar
 * Qualified Name:     com.neurosky.thinkgear.TF_TD_Libraries.Hjorth_Return
 * JD-Core Version:    0.6.0
 */