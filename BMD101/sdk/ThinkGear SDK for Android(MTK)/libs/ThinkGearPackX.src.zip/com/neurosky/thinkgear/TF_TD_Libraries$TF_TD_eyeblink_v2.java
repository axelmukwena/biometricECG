package com.neurosky.thinkgear;

public class TF_TD_Libraries$TF_TD_eyeblink_v2
{
  public TF_TD_Libraries$TF_TD_eyeblink_v2(TF_TD_Libraries paramTF_TD_Libraries)
  {
  }

  public double[] eyeblinkv2_fun(double[] paramArrayOfDouble)
  {
    int i = paramArrayOfDouble.length;
  }
}

/* Location:           C:\Users\Chris\Desktop\ThinkGear SDK for Android(MTK)\libs\ThinkGearPackX.jar
 * Qualified Name:     com.neurosky.thinkgear.TF_TD_Libraries.TF_TD_eyeblink_v2
 * JD-Core Version:    0.6.0
 */